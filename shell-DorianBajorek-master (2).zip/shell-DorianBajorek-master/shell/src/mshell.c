#include <stdio.h>

#include <unistd.h>

#include <sys/wait.h>

#include "config.h"

#include "siparse.h"

#include "utils.h"

#include <sys/types.h>

#include <sys/stat.h>

#include <string.h>

#include <stdlib.h>

#include <errno.h>

#include <fcntl.h>

#include "builtins.h"

#define BUF_LENGTH 4096

int number_of_children, background, number_of_notes, termalnRead;
pid_t children[MAX_LINE_LENGTH / 2];
sigset_t block_set, unblock_set;
struct sigaction sig_act;
int pipefd[2], prev_pipefd[2], notes[MAX_LINE_LENGTH][2];

int test(char ** argv) {
    for (int i = 0; builtins_table[i].name != NULL; i++) { //iteruje sie do napotknia nulaa
        if (!strcmp(builtins_table[i].name, argv[0])) {
            if (builtins_table[i].fun(argv)) {
                fprintf(stderr, "Builtin %s error.\n", argv[0]);
            }
            return 0;
        }
    }
    return 1;
}

void handler(int a) {
	while (1) {
		int status;
		pid_t k = waitpid(-1, &status, WNOHANG);
		if (k == -1 || k == 0)
		return;
		int x = -1;
		for (int i = 0; i < MAX_LINE_LENGTH / 2; i++) {
			if (children[i] == k) {
				x = i;
				break;
			}
		}
		if (x >= 0) {
			number_of_children--;
			children[x] = -1;
		} else {
			notes[number_of_notes][0] = k;
			notes[number_of_notes++][1] = status;
		}
  	}
}
//TODO
void writeNotes() {
  while (number_of_notes) {
    if (termalnRead) {
      if (WIFEXITED(notes[number_of_notes][1])) {
        printf("Background process %d terminated. (exited with status %d)\n", 
                notes[number_of_notes][0], notes[number_of_notes][1]);
      } else {
        printf("Background process %d terminated. (killed by signal %d)\n", 
                notes[number_of_notes][0], notes[number_of_notes][1]);
      }
    }
	number_of_notes--;
  }
}

int goodPipeline(pipelineseq * ln) {
    pipelineseq * tmp = ln;
    do {
        if (tmp -> pipeline -> commands -> com == NULL)
            return 0;
        tmp = tmp -> next;
    } while (tmp != ln);
    return 1;
}

void executeCom(command * com, char first_com, char last_com) {
    char * tabForArgs[1000];
    argseq * tmp;
    tmp = com -> args;
    int counter = 0;
    while (tmp != com -> args || counter == 0) {
        tabForArgs[counter] = tmp -> arg;
        tmp = tmp -> next;
        counter++;
    }
    tabForArgs[counter] = 0;
    if (!test(tabForArgs)) {
        return;
    }
    if (!last_com) {
        pipe(pipefd);
    }
    int k = 0;
    if ((k = fork())) { //mam potomka to mam czekać
        if (!first_com) {
            close(prev_pipefd[0]);
            close(prev_pipefd[1]);
        }
        prev_pipefd[0] = pipefd[0];
        prev_pipefd[1] = pipefd[1];
        if (!background) {
            children[number_of_children++] = k;
        }
    } else { //jestem klonem 
        if (background) {
            setsid();
        }
        int in = 0, out = 0;
        if (com -> redirs != NULL) {
            redirseq * rs = com -> redirs;
            redirseq * tmp_redir = rs;
            do {
                errno = 0;
                if (IS_RIN(rs -> r -> flags)) {
                    if (close(0)) {
                        perror(rs -> r -> filename);
                        exit(EXEC_FAILURE);
                    }
                    if (open(rs -> r -> filename, O_RDONLY) == -1) {
                        perror(rs -> r -> filename);
                        exit(EXEC_FAILURE);
                    } in = 1;
                } else if (IS_ROUT(rs -> r -> flags)) {
                    if (close(1)) {
                        perror(rs -> r -> filename);
                        exit(EXEC_FAILURE);
                    }
                    if (open(rs -> r -> filename, O_CREAT | O_TRUNC | O_WRONLY, 0644) == -1) {
                        perror(rs -> r -> filename);
                        exit(EXEC_FAILURE);
                    }
                    out = 1;
                } else if (IS_RAPPEND(rs -> r -> flags)) {
                    if (close(1)) {
                        perror(rs -> r -> filename);
                        exit(EXEC_FAILURE);
                    }
                    if (open(rs -> r -> filename, O_CREAT | O_APPEND | O_WRONLY, 0644) == -1) {
                        perror(rs -> r -> filename);
                        exit(EXEC_FAILURE);
                    }
                    out = 1;
                }
                rs = rs -> next;
            } while (rs != tmp_redir);
        }
        if (!first_com) {
            if (! in ) {
                if (dup2(prev_pipefd[0], 0) == -1) {
					perror(com ->args -> arg);
                	exit(EXEC_FAILURE);
				}
            }
            if (close(prev_pipefd[0]) || close(prev_pipefd[1])) {
				perror(com ->args -> arg);
                exit(EXEC_FAILURE);
			}
        }
        if (!last_com) {
            if (!out) {
                if (dup2(pipefd[1], 1) == -1) {
					perror(com ->args -> arg);
                	exit(EXEC_FAILURE);
				}
            }
            if (close(pipefd[0]) || close(pipefd[1])) {
				perror(com ->args -> arg);
                exit(EXEC_FAILURE);
			}
        }
        errno = 0;
        execvp(com -> args -> arg, tabForArgs);
        if (errno == 2) {
            fprintf(stderr, "%s: no such file or directory\n", com -> args -> arg);
        } else if (errno == 13) {
            fprintf(stderr, "%s: permission denied\n", com -> args -> arg);
        } else {
            fprintf(stderr, "%s: exec error\n", com -> args -> arg);
        }
        exit(EXEC_FAILURE);
    }
}

void invoker(char * buf, int size) {
    buf[size - 1] = 0;
    pipelineseq * ln = parseline(buf);
    if (ln == NULL)
        return;
    number_of_children = 0;
    pipelineseq * tmp_pipeline = ln;
    do {
        if (goodPipeline(tmp_pipeline)) {
            background = tmp_pipeline -> pipeline -> flags & INBACKGROUND;
            commandseq * comseq = ln -> pipeline -> commands;
            commandseq * tmp_com = comseq;
            int first_com = 1;
            do {
                executeCom(comseq -> com, first_com, comseq -> next == tmp_com);
                comseq = comseq -> next;
                first_com = 0;
            } while (comseq != tmp_com);
            if (!background) {
                while (number_of_children) {
                    sigsuspend(&unblock_set);
                }
				for (int i = 0; i < MAX_LINE_LENGTH / 2; i++) {
					children[i] = -1;
				}
            }
        }
        tmp_pipeline = tmp_pipeline -> next;
    } while (tmp_pipeline != ln);
}
//TODO
char * findEndFile(char buf[], int * elements_in_buffer) {
    char * end_line = strchr(buf, '\n');
    if (end_line == NULL && * elements_in_buffer > MAX_LINE_LENGTH) {
        while (1) {
            int ele_read = read(0, buf, 2 * MAX_LINE_LENGTH);
            end_line = strchr(buf, '\n');
            if (end_line != NULL) {
                * elements_in_buffer =
                    ele_read - (end_line - buf + 1);
                memmove(buf, end_line + 1, * elements_in_buffer);
                break;
            }
        }
        fprintf(stderr, "%s\n", SYNTAX_ERROR_STR);
        return NULL;
    }
    if (end_line == NULL ||
        end_line - buf >= * elements_in_buffer) // znaleziony koniec linii ale za aktualnymi elementami w tablicy
        return NULL;
    return end_line;
}
int main(int argc, char * argv[]) {

	sigemptyset(&block_set);
	sigaddset(&block_set, SIGCHLD);
	sigprocmask(SIG_BLOCK, &block_set, NULL);

    termalnRead = isatty(0);
    int readBox = 0;
    int leftBuf = 0;
    char buf[BUF_LENGTH];

	sig_act.sa_handler = handler;
	sig_act.sa_flags = 0;
	sigemptyset(&sig_act.sa_mask);
	sigaction(SIGCHLD, &sig_act, NULL);

    while (1) {
		writeNotes();
        if (termalnRead) {
            //Pisanie bez pliku: 
            printf("%s", PROMPT_STR);
            fflush(stdout);
            //return 0;
        }
		sigprocmask(SIG_UNBLOCK, &block_set, NULL);
        readBox = read(0, buf + leftBuf, BUF_LENGTH - leftBuf);
		sigprocmask(SIG_BLOCK, &block_set, &unblock_set);
		if (readBox == -1) {
			if (errno == EINTR) {
				continue;
			}
            return EXEC_FAILURE;
        }
        leftBuf += readBox;
        if (readBox == 0 && leftBuf == 0) {
            break;
        }
        while (1) {
            //szukam konca lini
            char * endLine = findEndFile(buf, & leftBuf);
            if (endLine == NULL)
                break;
            int cutSize = (endLine - buf);
            cutSize /= (sizeof(char));
            cutSize++;
            leftBuf -= cutSize;
            if (cutSize <= MAX_LINE_LENGTH && cutSize > 1) {
                invoker(buf, cutSize);
            } else if (cutSize > MAX_LINE_LENGTH) {
                fprintf(stderr, "%s\n", SYNTAX_ERROR_STR);
            }
            memmove(buf, endLine + 1, leftBuf);
        }
    }

    return 0;

    // ln = parseline("ls -las | grep k | wc ; ecs(buf, 20ho abc > f1 ;  cat < f2 ; echo abc >> f3\n");
    // printparsedline(ln);
    // printf("\n");
    // com = pickfirstcommand(ln);
    // printcommand(com,1);

    // ln = parseline("sleep 3 &");
    // printparsedline(ln);
    // printf("\n");

    // ln = parseline("echo  & abc >> f3\n");
    // printparsedline(ln);
    // printf("\n");
    // com = pickfirstcommand(ln);
    // printcommand(com,1);
}