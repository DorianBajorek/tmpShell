#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h> 
#include <dirent.h>
#include <signal.h>
//#include "shellFunction.c"
#include "builtins.h"

int echo(char*[]);
int exiter(char *[]);
int lcd(char *[]);
int lkiller(char *[]);
int undefined(char *[]);
int lls(char *[]);

builtin_pair builtins_table[]={
	{"exit",	&exiter},
	{"lecho",	&echo},
	{"lcd",		&lcd},
	{"lkill",	&lkiller},
	{"lls",		&lls},
	{NULL,NULL}
};

int 
echo( char * argv[])
{
	int i =1;
	if (argv[i]) printf("%s", argv[i++]);
	while  (argv[i])
		printf(" %s", argv[i++]);

	printf("\n");
	fflush(stdout);
	return 0;
}

int 
undefined(char * argv[])
{
	fprintf(stderr, "Command %s undefined.\n", argv[0]);
	return BUILTIN_ERROR;
}
int exiter(char *argv[]){
	exit(0);
	return BUILTIN_ERROR;
}
int lcd(char *argv[]) {
  if (argv[1] == NULL)
		if(chdir(getenv("HOME"))==0){
			return 0;
		}else{
			return BUILTIN_ERROR;
		}
  else if(argv[2] == NULL){
		if(chdir(argv[1]) == 0){
			return 0;
		}else{
			return BUILTIN_ERROR;
		}
	}
}
int lkiller(char *argv[]){
	if(argv[1]==NULL){
		return BUILTIN_ERROR;
	}else if(argv[2]==NULL){
		long pid=atoi(argv[1]);
		long sig=SIGTERM;
		kill(pid,sig);
	}else if(argv[3]==NULL){
		long pid=atoi(argv[2]);
		long sig=atoi(argv[1]);
		kill(pid,-sig);
	}else{
		return BUILTIN_ERROR;
	}
}
int lls(char *argv[]){
	struct dirent *singleFile;
	DIR *tmp=opendir(".");
	while((singleFile=readdir(tmp))!=NULL){
		if(singleFile->d_name[0]!='.'){
			printf("%s\n",singleFile->d_name);
		}
	}
	fflush(0);
}